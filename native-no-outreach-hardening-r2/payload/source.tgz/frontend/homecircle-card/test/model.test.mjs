import { test } from "node:test";
import assert from "node:assert/strict";
import {
  streetCityAddress,
  addressLabel,
  selection,
  visibleMembers,
  markerGroups,
  pinFitPadding,
  reportLabel,
  locationSince,
  validateConfig,
  providerAlertText,
} from "../src/model.js";
// Fictional origin and screen separation; never household coordinates.
const origin = 0,
  screenSeparation = 100;
const member = (id, presence = "home", focusable = true) => ({
  id,
  name: id,
  presence,
  focusable,
  location: focusable
    ? { latitude: origin, longitude: origin, evidence: { reported_at: null } }
    : null,
});
test("provider alerts use fixed messages and ignore unknown states", () => {
  assert.match(
    providerAlertText({ name: "Life360", state: "access_denied" }),
    /requests are paused/,
  );
  assert.match(
    providerAlertText({ name: "Life360", state: "paused" }),
    /paused; open HomeCircle settings to review or resume/,
  );
  assert.match(
    providerAlertText({ name: "Life360", state: "auth_required" }),
    /sign-in needs attention/,
  );
  assert.equal(
    providerAlertText({ name: "Life360", state: "connected" }),
    null,
  );
  assert.equal(providerAlertText({ name: "Life360", state: "invented" }), null);
  assert.match(
    providerAlertText({ name: "Life360", state: "selection_needed" }),
    /open HomeCircle Options to choose a tracker from this account/,
  );
});
test("Home focus excludes secondary residences while counts can include them", () => {
  const members = [
    member("house"),
    member("residence"),
    member("router", "home", false),
  ];
  assert.equal(members.filter((m) => m.presence === "home").length, 3);
  assert.deepEqual(
    selection(members, "home", { home: ["house"] }).map((m) => m.id),
    ["house"],
  );
  assert.deepEqual(
    selection(members, "overview", { overview: ["house", "residence"] }).map(
      (m) => m.id,
    ),
    ["house", "residence"],
  );
  assert.equal(selection(members, "router", {}).length, 0);
});
test("hidden members stay out of map and member selection", () => {
  const members = visibleMembers(
    { members: [member("visible"), member("hidden")] },
    ["hidden"],
  );
  assert.deepEqual(
    selection(members, "overview", { overview: ["visible", "hidden"] }).map(
      (m) => m.id,
    ),
    ["visible"],
  );
});
test("map-hidden members are omitted from Everyone but can be focused", () => {
  const members = visibleMembers({
    members: [
      member("visible"),
      { ...member("map-hidden"), map_visible: false },
    ],
  });
  assert.deepEqual(
    members.map((item) => item.id),
    ["visible", "map-hidden"],
  );
  assert.deepEqual(
    selection(members, "overview", { overview: ["visible", "map-hidden"] }).map(
      (item) => item.id,
    ),
    ["visible"],
  );
  assert.deepEqual(
    selection(members, "home", { home: ["visible", "map-hidden"] }).map(
      (item) => item.id,
    ),
    ["visible", "map-hidden"],
  );
  assert.deepEqual(
    selection(members, "map-hidden", {}).map((item) => item.id),
    ["map-hidden"],
  );
});
test("screen overlap groups remain individually selectable", () => {
  const members = [member("one"), member("two"), member("three")];
  members[2].location.longitude = screenSeparation;
  const groups = markerGroups(members, (p) => ({
    x: p.longitude,
    y: p.latitude,
  }));
  assert.deepEqual(
    groups.map((g) => g.members.map((m) => m.id)),
    [["one", "two"], ["three"]],
  );
});
test("pin fit padding leaves positive map area on narrow cards", () => {
  for (const size of [
    { x: 140, y: 220 },
    { x: 314, y: 220 },
    { x: 25, y: 25 },
  ]) {
    const { paddingTopLeft, paddingBottomRight } = pinFitPadding(size);
    assert.ok(paddingTopLeft[0] + paddingBottomRight[0] < size.x);
    assert.ok(paddingTopLeft[1] + paddingBottomRight[1] < size.y);
  }
  assert.deepEqual(pinFitPadding({ x: 314, y: 220 }), {
    paddingTopLeft: [112, 120],
    paddingBottomRight: [48, 48],
  });
});
test("a source report time is shown without claiming current movement", () => {
  const value = member("one");
  assert.match(reportLabel(value), /Update time unavailable/);
  value.location.evidence = {
    reported_at: "2026-01-01T00:00:00Z",
    freshness: "stale",
  };
  assert.match(
    reportLabel(value, Date.parse("2026-01-01T00:20:00Z")),
    /Stale report.*Location reported 20 min ago/,
  );
  assert.match(reportLabel(member("none", "home", false)), /No usable/);
});
test("selected tracker update time is the card fallback when no source report exists", () => {
  const value = member("phone");
  const now = Date.parse("2026-01-01T01:00:00Z");
  value.location.evidence.source_label = "Tracker: Example Phone";
  value.location.evidence.observed_at = "2026-01-01T00:26:00Z";
  assert.equal(
    reportLabel(value, now),
    "Tracker: Example Phone · HA tracker updated 34 min ago",
  );
  value.location.evidence.reported_at = "2026-01-01T00:50:00Z";
  value.location.evidence.freshness = "fresh";
  assert.equal(
    reportLabel(value, now),
    "Tracker: Example Phone · Location reported 10 min ago",
  );
  value.location.evidence.reported_at = null;
  value.location.evidence.observed_at = "2025-12-31T14:00:00Z";
  assert.equal(
    reportLabel(value, now),
    "Tracker: Example Phone · HA tracker updated 11 hours ago",
  );
  value.location.evidence.observed_at = "2026-01-01T01:10:00Z";
  assert.equal(
    reportLabel(value, now),
    "Tracker: Example Phone · Update time unavailable",
  );
  value.issues = ["tracker_presence_conflict"];
  assert.equal(
    reportLabel(value, now),
    "HA Person and selected tracker disagree · Map position withheld",
  );
});
test("street tiles default on, satellite and private choices persist, and invalid choices are rejected", () => {
  assert.equal(
    validateConfig({ type: "custom:homecircle-card" }).map_tiles,
    "osm",
  );
  assert.equal(
    validateConfig({ type: "custom:homecircle-card", map_tiles: "none" })
      .map_tiles,
    "none",
  );
  assert.equal(
    validateConfig({ type: "custom:homecircle-card", map_tiles: "satellite" })
      .map_tiles,
    "satellite",
  );
  assert.throws(() =>
    validateConfig({ type: "custom:homecircle-card", map_tiles: "unapproved" }),
  );
});

test("report ages use readable units without disguising stale or invalid evidence", () => {
  const value = member("one");
  const stamp = Date.parse("2026-01-01T00:00:00Z");
  value.location.evidence = {
    reported_at: new Date(stamp).toISOString(),
    freshness: "stale",
  };
  for (const [minutes, label] of [
    [0, "less than a minute"],
    [59, "59 min"],
    [60, "1 hour"],
    [1336, "22 hours"],
    [1440, "1 day"],
    [2880, "2 days"],
  ]) {
    assert.equal(
      reportLabel(value, stamp + minutes * 60000),
      `Stale report · Location reported ${label} ago`,
    );
  }
  value.location.evidence.reported_at = "invalid";
  assert.match(reportLabel(value), /Update time unavailable/);
});

test("card provider label replaces full tracker identity and preserves legacy fallback", () => {
  const value = member("example");
  value.location.evidence = {
    source_label: "Tracker: Example phone · Mobile App",
    card_source_label: "Tracker: Home Assistant",
  };
  assert.equal(
    reportLabel(value),
    "Tracker: Home Assistant · Update time unavailable",
  );
  delete value.location.evidence.card_source_label;
  assert.equal(
    reportLabel(value),
    "Tracker: Example phone · Mobile App · Update time unavailable",
  );
});

test("location Since uses the place transition rather than refresh or report time", () => {
  const current = {
    ...member("person.example_member"),
    place: "Home",
    primary_home: true,
    activity: {
      events: [{ kind: "started", observed_at: "2026-10-08T12:00:00Z" }],
    },
  };
  const now = Date.parse("2026-10-10T18:00:00Z");
  const states = {
    "person.example_member": {
      state: "home",
      last_changed: "2026-10-10T15:30:00Z",
      last_updated: "2026-10-10T17:59:00Z",
    },
  };
  const result = locationSince(current, states, "UTC", now);
  assert.match(result.text, /Since .*3:30|Since .*15:30/);
  assert.match(result.title, /detection may follow/);
  states["person.example_member"].last_updated = "2026-10-10T18:00:00Z";
  assert.equal(locationSince(current, states, "UTC", now).text, result.text);
  states["person.example_member"].last_changed = "2026-10-09T15:30:00Z";
  assert.match(locationSince(current, states, "UTC", now).text, /Oct.*9.*2026/);
  for (const changed of [
    "bad",
    "2026-10-11T15:30:00Z",
    "2026-10-10T15:30:00",
  ]) {
    states["person.example_member"].last_changed = changed;
    assert.equal(
      locationSince(current, states, "UTC", now).text,
      "Since unknown",
    );
  }
});
test("location Since does not invent an arrival for a moving, mismatched or unavailable place", () => {
  const current = {
    ...member("person.example_member"),
    place: "Library",
    activity: {
      events: [{ kind: "started", observed_at: "2026-10-10T12:00:00Z" }],
    },
  };
  const now = Date.parse("2026-10-10T18:00:00Z");
  const states = {
    "person.example_member": {
      state: "Library",
      last_changed: "2026-10-10T15:30:00Z",
    },
  };
  assert.notEqual(
    locationSince(current, states, "UTC", now).text,
    "Since unknown",
  );
  for (const fields of [
    { place: null },
    { place: "Office" },
    { focusable: false },
    { location: null },
    { presence: "driving" },
    { issues: ["gps_inside_zone_ha_pending"] },
  ])
    assert.equal(
      locationSince({ ...current, ...fields }, states, "UTC", now).text,
      "Since unknown",
    );
  assert.equal(locationSince(current, {}, "UTC", now).text, "Since unknown");
  assert.equal(
    locationSince(current, states, "bad zone", now).text,
    "Since unknown",
  );
  states["person.example_member"].state = "not_home";
  assert.equal(
    locationSince(current, states, "UTC", now).text,
    "Since unknown",
  );
});

test("Since excludes restart timestamps and missing observation boundaries", () => {
  const now = Date.parse("2026-10-10T18:00:00Z");
  const current = {
    ...member("person.example_member"),
    place: "Home",
    primary_home: true,
    activity: {
      events: [{ kind: "started", observed_at: "2026-10-10T15:30:02Z" }],
    },
  };
  const states = {
    "person.example_member": {
      state: "home",
      last_changed: "2026-10-10T15:30:00Z",
    },
  };
  assert.equal(
    locationSince(current, states, "UTC", now).text,
    "Since unknown",
  );
  states["person.example_member"].last_changed = "2026-10-10T16:00:00Z";
  assert.notEqual(
    locationSince(current, states, "UTC", now).text,
    "Since unknown",
  );
  assert.equal(
    locationSince({ ...current, activity: null }, states, "UTC", now).text,
    "Since unknown",
  );
});

test("persisted Since survives HA state recreation and remains honest about gaps", () => {
  const now = Date.parse("2026-10-10T18:00:00Z");
  const current = {
    ...member("person.example_member"),
    place: "Home",
    primary_home: true,
    arrival: {
      since: "2026-10-09T15:30:00Z",
      continuity_unconfirmed: true,
      persistent: true,
    },
  };
  const result = locationSince(current, {}, "UTC", now);
  assert.match(result.text, /Oct.*9.*2026/);
  assert.match(result.title, /uninterrupted presence is unconfirmed/);
  assert.equal(
    locationSince({ ...current, arrival: { since: null } }, {}, "UTC", now)
      .text,
    "Since unknown",
  );
});

test("all trackers use street and city without state or ZIP, with a truthful missing-city fallback", () => {
  for (const [input, expected] of [
    ["Example street, Example city", "Example street, Example city"],
    ["Example street, Example city, Wisconsin", "Example street, Example city"],
    ["Example street, Example city WI 00000", "Example street, Example city"],
    ["Example street, Wisconsin", "Example street"],
    ["Example street, WI 00000", "Example street"],
    ["Example street", "Example street"],
    ["Wisconsin", null],
  ])
    assert.equal(streetCityAddress(input), expected);
  for (const id of [
    "device_tracker.example_phone",
    "device_tracker.example_item",
  ]) {
    const value = {
      ...member(id, "away"),
      reported_address: "Example street, Example city, Wisconsin",
    };
    value.location.evidence.freshness = "stale";
    assert.equal(
      addressLabel(value),
      "Last reported: Example street, Example city",
    );
    value.location.evidence.freshness = "fresh";
    assert.equal(addressLabel(value), "At Example street, Example city");
  }
});

test("city names matching states remain visible with a region component or lookup text", () => {
  assert.equal(
    streetCityAddress("Example street, New York, NY"),
    "Example street, New York",
  );
  assert.equal(
    streetCityAddress("Example street, Washington, DC"),
    "Example street, Washington",
  );
  assert.equal(
    streetCityAddress("Example street, Georgia, VT"),
    "Example street, Georgia",
  );
  assert.equal(
    streetCityAddress("Example street, New York"),
    "Example street, New York",
  );
  assert.equal(streetCityAddress("Washington"), "Washington");
});

test("structured lookup cities are not interpreted as regions", () => {
  assert.equal(
    streetCityAddress("Example street, Georgia", "Georgia"),
    "Example street, Georgia",
  );
  assert.equal(streetCityAddress("Georgia", "Georgia"), "Georgia");
});

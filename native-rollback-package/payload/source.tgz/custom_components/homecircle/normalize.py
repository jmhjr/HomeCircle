"""Pure normalization of selected HA person and tracker state snapshots.

No I/O, history, or provider credentials. GPS selection uses report evidence.
"""

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime, timedelta
from math import isfinite
from typing import Any

from homeassistant.const import ATTR_LATITUDE, ATTR_LONGITUDE
from homeassistant.core import State
from homeassistant.util import dt as dt_util
from homeassistant.util.location import distance

from .const import (
    CONF_MEMBERS,
    CONF_ITEMS,
    CONF_PEOPLE,
    CONF_TRACKER_PEOPLE,
    CONF_PETS,
    CONF_PLACES,
    CONF_PRIMARY_HOME,
    CONF_RESIDENCES,
    CONF_TRACKERS,
    CONF_DISPLAY_NAME,
)

STALE_AFTER_SECONDS = 300
UNKNOWN_STATES = {"unknown", "unavailable"}


@dataclass(frozen=True)
class Evidence:
    source_entity: str | None
    observed_at: datetime | None
    reported_at: datetime | None = None
    report_entity: str | None = None
    freshness: str = "unknown"
    report_status: str = "not_configured"


@dataclass(frozen=True)
class Location:
    latitude: float
    longitude: float
    accuracy: float | None
    origin: str
    evidence: Evidence


@dataclass(frozen=True)
class OptionalValue:
    value: float | bool | None
    evidence: Evidence
    unit: str | None = None


@dataclass(frozen=True)
class Member:
    id: str
    display_name: str
    kind: str
    person_entity: str | None
    source_entity: str
    active_source_entity: str | None
    presence: str
    presence_evidence: Evidence
    residence: str | None
    place: str | None
    primary_home: bool
    location: Location | None
    driving: OptionalValue
    driving_status: str
    battery: OptionalValue
    charging: OptionalValue
    speed: OptionalValue
    issues: tuple[str, ...]
    battery_status: OptionalValue | None = None
    source_selection_reason: str = "Following Home Assistant Person."

    @property
    def focusable(self) -> bool:
        return (
            self.presence != "unavailable"
            and self.location is not None
            and not {
                "tracker_presence_conflict",
                "person_tracker_location_conflict",
            }.intersection(self.issues)
        )


@dataclass(frozen=True)
class Household:
    members: tuple[Member, ...]
    counts: dict[str, int]
    primary_home_ids: tuple[str, ...]
    focus_ids: dict[str, tuple[str, ...]]


def available(state: State | None) -> bool:
    return state is not None and state.state not in UNKNOWN_STATES


def number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if isfinite(result) else None


def coordinates(state: State | None) -> tuple[float, float, float | None] | None:
    if not available(state):
        return None
    lat = number(state.attributes.get(ATTR_LATITUDE))
    lon = number(state.attributes.get(ATTR_LONGITUDE))
    if lat is None or lon is None or not -90 <= lat <= 90 or not -180 <= lon <= 180:
        return None
    accuracy = number(state.attributes.get("gps_accuracy"))
    if accuracy is not None and accuracy < 0:
        accuracy = None
    return lat, lon, accuracy


def evidence(
    source: State | None,
    report: State | None,
    now: datetime,
    report_id: str | None = None,
    stale_after_seconds: float = STALE_AFTER_SECONDS,
) -> Evidence:
    base = dict(
        source_entity=source.entity_id if source else None,
        observed_at=source.last_updated if source else None,
        report_entity=report_id,
    )
    if report_id is None:
        return Evidence(**base)
    if not available(source) or not available(report):
        return Evidence(**base, report_status="unavailable")
    parsed = dt_util.parse_datetime(report.state)
    if parsed is None or parsed.tzinfo is None:
        return Evidence(**base, report_status="invalid")
    parsed = dt_util.as_utc(parsed)
    age = (now - parsed).total_seconds()
    if age < -60:
        return Evidence(**base, report_status="future")
    return Evidence(
        **base,
        reported_at=parsed,
        report_status="explicit_sensor",
        freshness="fresh" if age <= stale_after_seconds else "stale",
    )


def location_evidence(
    source: State,
    report: State | None,
    now: datetime,
    report_id: str | None,
    stale_after_seconds: float,
) -> Evidence:
    """Use an explicit sensor first, then a GPS tracker's own report time."""
    if report_id is not None:
        return evidence(source, report, now, report_id, stale_after_seconds)
    base = evidence(source, None, now)
    if source.attributes.get("source_type") != "gps":
        return base
    value = source.attributes.get("last_seen")
    parsed = (
        value
        if isinstance(value, datetime)
        else (dt_util.parse_datetime(value) if isinstance(value, str) else None)
    )
    if parsed is None or parsed.tzinfo is None:
        return base
    parsed = dt_util.as_utc(parsed)
    age = (now - parsed).total_seconds()
    if age < -60:
        return base
    return Evidence(
        source_entity=source.entity_id,
        observed_at=source.last_updated,
        reported_at=parsed,
        report_status="tracker_attribute",
        freshness="fresh" if age <= stale_after_seconds else "stale",
    )


def tracker_optional(source: State, attribute: str, kind: str) -> OptionalValue:
    """Read common battery fields only from the selected location tracker."""
    value = source.attributes.get(attribute) if available(source) else None
    if kind == "battery":
        value = number(value)
        if value is None or not 0 <= value <= 100:
            value = None
    elif not isinstance(value, bool):
        value = None
    return OptionalValue(
        value,
        Evidence(source_entity=source.entity_id, observed_at=source.last_updated),
        "%" if kind == "battery" and value is not None else None,
    )


def tracker_battery_status(source: State | None, now: datetime) -> OptionalValue | None:
    """Keep coarse battery categories and their actual report time separate from percent."""
    if not available(source):
        return None
    value = source.attributes.get("battery_status")
    if value not in ("full", "medium", "low", "very_low"):
        return None
    raw = source.attributes.get("battery_status_reported_at")
    reported = dt_util.parse_datetime(raw) if isinstance(raw, str) else None
    if reported is not None and (
        reported.tzinfo is None or reported > now + timedelta(seconds=60)
    ):
        reported = None
    return OptionalValue(
        value,
        Evidence(
            source_entity=source.entity_id,
            observed_at=source.last_updated,
            reported_at=reported,
        ),
    )


def tracker_driving(source: State, now: datetime) -> OptionalValue:
    """Use a selected GPS tracker's driving flag only with its report freshness."""
    value = source.attributes.get("driving") if available(source) else None
    if not isinstance(value, bool):
        value = None
    return OptionalValue(
        value,
        location_evidence(source, None, now, None, STALE_AFTER_SECONDS),
    )


def optional_value(states, entity_id, now, kind, report_id=None) -> OptionalValue:
    state = states.get(entity_id)
    proof = evidence(state, states.get(report_id), now, report_id)
    value = None
    unit = None
    if available(state):
        if kind == "boolean":
            value = {"on": True, "off": False}.get(state.state)
        elif kind == "charging":
            value = {
                "on": True,
                "off": False,
                "charging": True,
                "not charging": False,
                "full": False,
            }.get(state.state.strip().lower())
        else:
            unit = state.attributes.get("unit_of_measurement")
            parsed = number(state.state)
            if (
                kind == "battery"
                and unit == "%"
                and parsed is not None
                and 0 <= parsed <= 100
            ):
                value = parsed
            elif (
                kind == "speed"
                and unit in {"m/s", "km/h", "mph"}
                and parsed is not None
                and parsed >= 0
            ):
                value = parsed
            if value is None:
                unit = None
    return OptionalValue(value, proof, unit)


def membership(
    person_state: State, selected: list[str], states, zone_names, source, now
) -> tuple[list[str], list[str]]:
    """Resolve IDs first; legacy names only if globally unique in HA's zone catalog."""
    issues = []
    raw = person_state.attributes.get("in_zones")
    if isinstance(raw, (list, tuple)) and all(isinstance(item, str) for item in raw):
        matches = [item for item in selected if item in raw]
        if raw:
            return matches, issues
    if person_state.state == "home":
        return (["zone.home"] if "zone.home" in selected else []), [
            "legacy_home_membership"
        ]
    if person_state.state == "not_home":
        # A newly added zone does not reclassify an existing GPS state until
        # that tracker reports again. Use a recent, well-inside position only.
        if source is not None and source.attributes.get("source_type") == "gps":
            point = coordinates(source)
            person_point = coordinates(person_state)
            raw_report = source.attributes.get("last_seen")
            reported = (
                raw_report
                if isinstance(raw_report, datetime)
                else dt_util.parse_datetime(raw_report)
                if isinstance(raw_report, str)
                else None
            )
            observed = reported if reported and reported.tzinfo else source.last_updated
            if (
                point is not None
                and point[2] is not None
                and person_point is not None
                and person_point[:2] == point[:2]
                and observed.tzinfo is not None
                and 0 <= (now - observed).total_seconds() <= 900
            ):
                geometric = []
                for zone_id in selected:
                    zone = states.get(zone_id)
                    zone_point = coordinates(zone)
                    radius = number(zone.attributes.get("radius")) if zone else None
                    if (
                        zone_point is None
                        or radius is None
                        or radius <= 0
                        or zone.attributes.get("passive")
                    ):
                        continue
                    meters = distance(point[0], point[1], zone_point[0], zone_point[1])
                    if meters is not None and meters + point[2] <= radius:
                        geometric.append(zone_id)
                if len(geometric) == 1:
                    return geometric, ["gps_inside_zone_ha_pending"]
        return [], issues
    matches = [key for key, name in zone_names.items() if name == person_state.state]
    if len(matches) == 1 and matches[0] in selected:
        return matches, ["legacy_zone_name"]
    if person_state.state == "driving" and not matches:
        return [], issues
    return [], ["ambiguous_zone_name" if len(matches) > 1 else "unresolved_place"]


def freshest_gps(member_config, states, active, now):
    """Rank selected GPS reports; HA update times never establish freshness."""
    candidates = []
    supporting = member_config.get("supporting", {})
    reports = member_config.get("location_reports", {})
    for tracker_id in member_config[CONF_TRACKERS]:
        tracker = states.get(tracker_id)
        if (
            not available(tracker)
            or tracker.attributes.get("source_type") != "gps"
            or coordinates(tracker) is None
        ):
            continue
        report_id = reports.get(tracker_id)
        if report_id is None and supporting.get("location_report_source") == tracker_id:
            report_id = supporting.get("location_reported_at")
        proof = location_evidence(
            tracker, states.get(report_id), now, report_id, STALE_AFTER_SECONDS
        )
        if proof.reported_at is not None:
            candidates.append((tracker, proof))
    if not candidates:
        return None, "No verified GPS report times; following Home Assistant Person."
    fresh = [item for item in candidates if item[1].freshness == "fresh"]
    if not fresh:
        return None, "No fresh verified GPS reports; following Home Assistant Person."
    pool = fresh
    newest = max(pool, key=lambda item: item[1].reported_at)
    # Prefer HA's selected GPS source only when its report is nearly as recent.
    close = [
        item
        for item in pool
        if (newest[1].reported_at - item[1].reported_at).total_seconds() <= 60
    ]
    chosen = next((item for item in close if item[0].entity_id == active), newest)
    reason = "Freshest verified GPS report."
    if chosen != newest:
        reason += " HA's active selected GPS tracker is within 60 seconds of the newest report."
    return chosen[0], reason


def gps_zone_membership(source, selected, states):
    """Classify the chosen GPS position against HA zone geometry."""
    point = coordinates(source)
    matched = []
    for zone_id in selected:
        zone = states.get(zone_id)
        zone_point = coordinates(zone)
        radius = number(zone.attributes.get("radius")) if available(zone) else None
        if (
            zone_point is None
            or radius is None
            or radius <= 0
            or zone.attributes.get("passive")
        ):
            continue
        meters = distance(point[0], point[1], zone_point[0], zone_point[1])
        accuracy = point[2] or 0
        if meters is not None and meters - radius < accuracy:
            matched.append(zone_id)
    return matched


def normalize_member(
    person_id, member_config, config, states, zone_names, now
) -> Member:
    tracker_only_member = person_id.startswith("device_tracker.")
    person_state = states.get(person_id)
    original_person_state = person_state
    selected_trackers = member_config[CONF_TRACKERS]
    supporting = member_config.get("supporting", {})
    issues = []
    active = person_id if tracker_only_member else None
    if not tracker_only_member and person_state:
        active = person_state.attributes.get("source")
    if not isinstance(active, str) or not active.startswith("device_tracker."):
        active = None
    ha_active = active
    chosen_gps = None
    selection_reason = "Following Home Assistant Person."
    if (
        not tracker_only_member
        and member_config.get("tracker_selection", "freshest_gps") == "freshest_gps"
    ):
        chosen_gps, selection_reason = freshest_gps(member_config, states, active, now)
        if chosen_gps is not None:
            person_state = chosen_gps
            active = chosen_gps.entity_id
    elif tracker_only_member:
        selection_reason = "Using this member's explicitly selected tracker."
    source = states.get(active) if active in selected_trackers else None
    driving = optional_value(
        states,
        supporting.get("driving"),
        now,
        "boolean",
        supporting.get("driving_reported_at"),
    )
    if (
        not supporting.get("driving")
        and source is not None
        and source.attributes.get("source_type") == "gps"
    ):
        driving = tracker_driving(source, now)
    battery = optional_value(states, supporting.get("battery"), now, "battery")
    charging = optional_value(states, supporting.get("charging"), now, "charging")
    speed = optional_value(states, supporting.get("speed"), now, "speed")
    driving_status = "unknown"
    if driving.value is not None:
        driving_status = {
            "fresh": "current",
            "stale": "last_reported",
            "unknown": "unverified",
        }[driving.evidence.freshness]
    residence = place = None
    primary_home = False
    location = None
    presence = "unavailable"
    if available(person_state):
        residences = [config[CONF_PRIMARY_HOME], *member_config[CONF_RESIDENCES]]
        selected_zones = list(dict.fromkeys([*residences, *config[CONF_PLACES]]))
        if chosen_gps is not None:
            matched = gps_zone_membership(chosen_gps, selected_zones, states)
            zone_issues = []
        else:
            matched, zone_issues = membership(
                person_state, selected_zones, states, zone_names, source, now
            )
        issues.extend(zone_issues)
        valid = [item for item in matched if available(states.get(item))]
        residence = next((item for item in residences if item in valid), None)
        primary_home = config[CONF_PRIMARY_HOME] in valid
        place = residence or next(iter(valid), None)
        presence = "home" if residence else "away"
        # A Person may inherit Home from a stationary linked tracker while an
        # explicitly selected mobile GPS tracker reports Away. Detect this even
        # when HA supplies borrowed Home coordinates for the Person.
        if (
            chosen_gps is None
            and residence
            and "gps_inside_zone_ha_pending" not in zone_issues
            and any(
                available(states.get(tracker_id))
                and states[tracker_id].attributes.get("source_type") == "gps"
                and states[tracker_id].state == "not_home"
                for tracker_id in selected_trackers
            )
        ):
            issues.append("tracker_presence_conflict")
        if not residence and any(
            item in residences for item in matched if item not in valid
        ):
            presence = "unavailable"
            issues.append("residence_zone_unavailable")
        elif driving.value is True and driving_status == "current":
            presence = "driving"

        point = coordinates(person_state)
        location_source = person_state
        origin = "ha_person"
        # HA can borrow Home coordinates for a locationless legacy tracker.
        # Only inspect explicitly selected sources; do not silently widen selection.
        if active in selected_trackers:
            if not available(source):
                point = None
                issues.append("active_source_unavailable")
            elif coordinates(source) is None:
                point = None
                issues.append("active_source_locationless")
            elif point is not None and source.attributes.get("source_type") == "gps":
                if point[:2] == coordinates(source)[:2]:
                    origin = "active_gps"
                    location_source = source
                else:
                    issues.append("person_tracker_location_conflict")
        elif point is not None:
            issues.append("location_source_unverified")
        if point is None:
            candidates = [
                states.get(item)
                for item in selected_trackers
                if available(states.get(item))
                and states[item].attributes.get("source_type") == "gps"
                and coordinates(states[item]) is not None
            ]
            # An available HA active GPS source is authoritative among selected sources.
            candidate = (
                source
                if source in candidates
                else (candidates[0] if len(candidates) == 1 else None)
            )
            if candidate is not None:
                point = coordinates(candidate)
                location_source = candidate
                origin = "supplemental_gps"
                if candidate.state != person_state.state or (
                    isinstance(candidate.attributes.get("in_zones"), (list, tuple))
                    and isinstance(
                        person_state.attributes.get("in_zones"), (list, tuple)
                    )
                    and all(
                        isinstance(item, str)
                        for item in candidate.attributes["in_zones"]
                    )
                    and all(
                        isinstance(item, str)
                        for item in person_state.attributes["in_zones"]
                    )
                    and set(candidate.attributes["in_zones"])
                    != set(person_state.attributes["in_zones"])
                ):
                    if "tracker_presence_conflict" not in issues:
                        issues.append("tracker_presence_conflict")
            elif len(candidates) > 1:
                issues.append("ambiguous_gps_sources")
        if point is not None and presence != "unavailable":
            reports = member_config.get("location_reports", {})
            report_id = reports.get(location_source.entity_id) or supporting.get(
                "location_reported_at"
            )
            if (
                location_source.entity_id not in reports
                and supporting.get("location_report_source")
                != location_source.entity_id
            ):
                if report_id and chosen_gps is None:
                    issues.append("location_report_source_mismatch")
                report_id = None
            stale_after = STALE_AFTER_SECONDS
            if member_config.get("kind") == "pet":
                key, default = (
                    ("pet_home_minutes", 1440) if residence else ("pet_away_minutes", 5)
                )
                stale_after = member_config.get(key, default) * 60
            proof = location_evidence(
                location_source, states.get(report_id), now, report_id, stale_after
            )
            if chosen_gps is not None:
                origin = "freshest_gps"
            location = Location(*point, origin=origin, evidence=proof)
            if location_source.entity_id in selected_trackers:
                if not supporting.get("battery"):
                    battery = tracker_optional(
                        location_source, "battery_level", "battery"
                    )
                if not supporting.get("charging"):
                    charging = tracker_optional(
                        location_source, "battery_charging", "boolean"
                    )
    else:
        issues.append(
            "tracker_unavailable" if tracker_only_member else "person_unavailable"
        )
    return Member(
        id=person_id,
        display_name=member_config.get(CONF_DISPLAY_NAME)
        or (original_person_state.name if original_person_state else person_id),
        kind=member_config.get("kind", "person"),
        person_entity=None if tracker_only_member else person_id,
        source_entity=person_id,
        active_source_entity=ha_active,
        presence=presence,
        presence_evidence=evidence(person_state, None, now),
        residence=residence,
        place=place,
        primary_home=primary_home,
        location=location,
        driving=driving,
        driving_status=driving_status,
        battery=battery,
        battery_status=tracker_battery_status(
            states.get(location.evidence.source_entity) if location else source, now
        ),
        charging=charging,
        speed=speed,
        issues=tuple(issues),
        source_selection_reason=selection_reason,
    )


def normalize_household(
    config: Mapping[str, Any],
    states: Mapping[str, State | None],
    now: datetime,
    zone_names: Mapping[str, str] | None = None,
) -> Household:
    """Make counts and focus subsets from the same normalized records."""
    if now.tzinfo is None:
        raise ValueError("Normalization requires an aware timestamp")
    names = (
        zone_names
        if zone_names is not None
        else {
            key: value.name
            for key, value in states.items()
            if key.startswith("zone.") and value is not None
        }
    )
    members = tuple(
        normalize_member(item, config[CONF_MEMBERS][item], config, states, names, now)
        for item in [
            *config.get(CONF_PEOPLE, []),
            *config.get(CONF_TRACKER_PEOPLE, []),
            *config.get(CONF_PETS, []),
            *config.get(CONF_ITEMS, []),
        ]
    )
    categories = ("home", "away", "driving", "unavailable")
    counts = {
        category: sum(
            item.presence == category and item.kind != "item" for item in members
        )
        for category in categories
    }
    primary_ids = tuple(
        item.id
        for item in members
        if item.presence == "home" and item.primary_home and item.kind != "item"
    )
    focus = {
        category: tuple(
            item.id
            for item in members
            if item.presence == category
            and item.kind != "item"
            and item.focusable
            and (category != "home" or item.primary_home)
        )
        for category in categories
    }
    if any(item.kind == "item" for item in members):
        counts["items"] = sum(item.kind == "item" for item in members)
        focus["items"] = tuple(
            item.id for item in members if item.kind == "item" and item.focusable
        )
    focus["overview"] = tuple(item.id for item in members if item.focusable)
    focus["all_residences"] = tuple(
        item.id
        for item in members
        if item.presence == "home" and item.focusable and item.kind != "item"
    )
    return Household(members, counts, primary_ids, focus)

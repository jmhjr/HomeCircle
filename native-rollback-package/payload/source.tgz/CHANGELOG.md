# Changelog

## Unreleased — 1.0 preparation

- Keep the selected picture filename visible through cropping and unsuccessful uploads, with safe clearing on save, removal and navigation.
- Exclude passive residences from the legacy geometric fallback while preserving explicit HA Person membership.
- Drain owned city-cache work during unload and preserve actual caller cancellation; prevent raw shielded-write diagnostics after cancellation while retaining the existing disk-error cleanup policy.
- Carry the separate inherited and supplemental notice corrections and narrowly recognize their exact public-license bytes in the privacy checker.
- Track the [1.0 release plan](docs/RELEASE-1.0-PLAN.md), focused corrections and remaining acceptance. No stable version or replacement beta 20 package is published.

## 0.1.0-beta.20 — October 20, 2026

Experimental prerelease; see the [versioned validation boundary](docs/BETA20-VALIDATION.md).
This packages the separately reviewed hardening candidate. Publication and genuine HACS
delivery/restart are separate acceptance steps; it is not a stable-release approval.

- Preserve polling progress and older authenticated reports across later failures; isolate provider startup and shutdown failures.
- Keep GSA/recovery SRP state separate, verify peer/key and account/session bindings, authenticate protected records, and bound recovery/native-worker resources.
- Persist a separate recovery submission safeguard and preserve selected-item identities and safe display settings without keeping omitted tracking keys. Reject ambiguous identity matches and stale/concurrent selection saves.
- Correct verified-byte worker loading, native cleanup, entropy and buffer bounds; retain complete inherited notices.
- Document package-only rollback's identity-ledger limit and the requirement to preserve the newest independent recovery safeguard. Prepared disabled-entry Supervisor partial-backup/Recorder restoration passed with synthetic data; ordinary enabled-entry/full-system and owner recovery remain unqualified.
- Retain the frozen V2 reference, ordinary HA tracker selection, existing provider choices and genuine source report times. No production rollout is part of this prerelease.

## 0.1.0-beta.19 — October 19, 2026

Experimental prerelease. See [package and functional acceptance](docs/FINDMY-BETA19-PACKAGING-VALIDATION.md) and the [earlier candidate record](docs/BETA19-CANDIDATE-VALIDATION.md). Publication and HACS verification are separate release steps.

- Include Apple Find My as a native HomeCircle provider using a pinned MIT Python SDK, with Linux API polling and no Mac or separate production helper.
- Add guided account sign-in, verification, explicit Keychain recovery consent for discovery, selected-item multi-selection/types, reconnect using existing keys, and independent account polling/repairs.
- Store only selected item keys and a minimized encrypted report session; erase native stores on disconnect/removal and clean orphaned native stores.
- Add an Items category while preserving existing explicit people/pet roles, custom names, photos, actual report times and recorder entity history.
- Add account-bound Mac identity provisioning on HA, automatic hash-verified acquisition of the public Apple runtime, and passwordless restart restoration without a physical Mac. Apple binaries and provisioned identities are excluded from the release ZIP.
- Use the working report-service headers with bounded gzip decoding while retaining the SDK's report request body, source timestamps, estimated accuracy and battery categories.
- Add sanitized sign-in phase and passive polling diagnostics that distinguish returned reports from retained older locations without extra Apple requests.
- Return the Apple login form directly when a saved identity is already prepared, avoiding a stalled pre-password spinner. Cancelled or missing setup tasks end without advancing authentication.
- Omit prototype migration and Undo from public onboarding.
- Validate the deterministic ZIP in disposable HA Core lifecycle processes and on the HA OS Raspberry Pi. Fresh Apple discovery/selection, passwordless restart and automatic decoded report delivery passed with two selected trackers and no duplicate entities. Source-report freshness, new physical movement and delivery latency remain unproven; beta 18 tracking, places, picture controls and the frozen V2 reference are preserved.

## 0.1.0-beta.18 — October 11, 2026

Experimental prerelease; see the [change record](docs/RECENT-CHANGES-2026-10-11.md) and [validation](docs/BETA18-VALIDATION.md).

- Default Person members to the freshest verified report among explicitly selected GPS trackers, with HA active-source preference within 60 seconds and an opt-out to Follow HA Person. Derive HomeCircle zones from the chosen position; preserve report provenance and stale labels.
- Import saved Life360 places through an existing saved account. Add multi-selection, Select all, filtering, per-place map review and Skip, final confirmation, duplicate protection and partial-failure retry. Imported zones are ordinary places until separately assigned as homes.
- Add native HA picture upload for tracker-only members with local crop, zoom and positioning; show pictures in cards and Details. Preserve Person picture management and do not delete native uploaded images when removing a reference.
- Show coarse tracker battery categories and actual battery report times without inventing percentages.
- Use Street, City address labels across providers. Add optional server-side Photon lookup, off by default, with explicit coordinate disclosure, bounded persisted budgets/cache, cancellation and attribution.
- Use fixed zoom 17 on member selection and align member cards within rows.
- Harden fragmented geocoder response handling and cache cleanup; preserve limits on clock rollback. Repair Primary Home changes, include GPS accuracy in zone matching, and guard uploads completing after navigation.

- Follow new location coordinates for a selected person while retaining the chosen zoom. Keep Everyone/category views steady on background updates.

- Accept explicitly mapped phone battery-state sensors for charging, alongside existing binary sensors. Charging is true; Not Charging and Full are false; unavailable or unrecognized reports remain unknown.

- Prefer genuine Life360 arrival timestamps for Since; retain observed named-place arrivals across HA restarts with observation-gap disclosure. Exclude pet report times masquerading as arrivals.


- Render person-card information buttons with a clean circled inline SVG so the icon remains visible on DAKboard devices whose fonts lack the information glyph.

- Align the recenter control with the zoom pill and give it a centered crosshair, circular hit area and matching dark blue outline.

- Family refresh now uses explicitly assigned supported trackers across providers, including sources that are not currently driving the map. Opted-in Home Assistant phones use same-device notification targets; external Life360 uses a complete selected Circle or a supported targeted action, and managed connections check cloud reports.
- Report unsupported/disabled/failed/limited trackers individually and distinguish an HA receipt from a confirmed GPS report. Preserve persisted budgets, permissions, provider backoff and bounded report observation.


## 0.1.0-beta.17 — October 10, 2026

Experimental prerelease incorporating the reconciled beta 16 candidate. The complete implementation and validation record is in [recent changes](docs/RECENT-CHANGES-2026-10-10.md).

- Require administrator opt-in for external Life360 family refresh, disclose saved-account use and viewer control permissions, escape setup description names, and prevent no-op selection requests from evicting activity.
- Freeze family-refresh outcomes at the two-minute observation boundary, expire feedback after five minutes, and protect significant activity from freshness churn.
- Explain HA Person/tracker conflicts using configured associations and the active source; keep report time distinct from HA update time. Simplify tracker labels to provider names, including Home Assistant.
- Add opt-in phone location requests, bounded selected-person refresh and explicit family refresh. Retain failed attempts and limits across restarts: 50 attempts per rolling 24 hours, one-minute deliberate cooldowns, with separate per-tracker and family counters. Automatic phone attempts wait 15 minutes and pause after three unanswered automatic attempts.
- Improve person Details, troubleshooting, source evidence and refresh feedback; add a local Recent activity timeline bounded to seven days and 100 events per member. Fix Settings cancellation and overlapping Back navigation races.
- Improve overview counts, low-battery warnings, card spacing, place labels and reported addresses. Use an outlined kiosk icon button.
- Add Street/Satellite controls, a compact three-part Street/Radar/Satellite pill, a dark-blue zoom pill, draggable map height and a tighter footer. Zoom centers visible pins; empty categories and views with no visible pins retain their current view. Person selection zooms three levels above Everyone.
- Add opt-in IEM observed radar and HRRR forecasts with dated frame times, model-run labels, animation, 40% opacity and optional browser-local opacity/legend controls. Correct Leaflet radar removal to prevent blank tiles after zooming.
- Preserve manual map views and radar playback during coordinate updates; provide an explicit recenter icon. Preserve the last snapshot through temporary failures with a visible warning, while permission errors clear it.
- Reset radar metadata on toggle, fall back honestly when time lookup fails, refresh on visibility resume, rebuild future frame times, and retain visible radar while animation buffers.
- Prevent Person Details saves from silently linking selected trackers to HA Persons. Keep explicit Assign/Add links and disclose them before save; allow unlinked selections for YAML-managed Persons.
- Add private field-state capture, offline transition analysis and synthetic capture-to-report rehearsal. Recording gaps remain explicit; combined-source field evidence does not prove an iPhone-only cycle or exact app response latency.

## 0.1.0-beta.16 — experimental prerelease

- Keep the map visible while the member list scrolls inside a card outside kiosk mode, including full-screen cards.
- Leave members with Show member on map off out of Everyone's map fit. Selecting their card or status category shows their position.
- Preserve each member card's content height so details do not overlap while the list scrolls. Refresh the owned card resource URL whenever its bundle changes.

## 0.1.0-beta.15 — included in beta 16, not published separately

- Use the selected GPS tracker's own driving flag when no separate driving sensor is configured. Require a fresh tracker location report before showing Driving; label an old positive flag as last reported. Preserve explicitly selected driving sensors and never infer driving from speed alone.
- Recognize a provider's `driving` Person state as travel rather than an unknown place when no selected zone matches.
- Explain the tracker fallback in both setup and Options status-sensor screens.

## 0.1.0-beta.14 — experimental prerelease

- Show the registered tracker integration beside a location source when the tracker's name alone does not identify it. A Life360 Pet GPS tracker named the pet now reads `Tracker: the pet · Life360 Pet GPS`.

## 0.1.0-beta.13 — experimental prerelease

- Create a HomeCircle dashboard and card during first setup when neither already exists; preserve existing dashboards and remove only an untouched HomeCircle-created dashboard on uninstall.
- Require a Home Assistant Person for each newly added person or pet. Select or create the Person, assign a tracker, then configure that member. Keep older tracker-only members and offer a settings-preserving move to a Person.
- Open task-based settings over the dashboard from a cog in the card header. Keep the same choices in Home Assistant's Configure flow, including focused tracker add, remove, map visibility, sensor, and household tasks.
- Create missing Home Assistant zones during setup, clarify the purpose of Away places, and add Back navigation without discarding other member selections.
- Default new cards to OpenStreetMap street tiles while retaining a Private setting that makes no external tile requests.
- Identify the device behind each map position and keep Home Assistant state-update time separate from genuine location-report time. Filter battery sensor choices to relevant candidates while preserving saved mappings.
- Show `HomeCircle - Beta 13` on default card titles from the integration version; retain custom titles.

## 0.1.0-beta.12 — experimental prerelease

- Shorten initial household setup with a clearer review step and guidance for choosing Home Assistant people and trackers.
- Add a focused path in Options to add one new tracker without reconfirming every existing household member.
- Let an existing tracker be removed from the household or kept as a member while its map marker is hidden.
- Add an administrator Settings button to the map card header. It opens HomeCircle's Home Assistant integration page and stays hidden in kiosk view.

## 0.1.0-beta.11 — experimental prerelease

- Let an existing Home Assistant device tracker be selected directly as a pet, without creating a Person record. The pet uses that tracker for presence and location, with its own residences, freshness limits and optional supporting sensors.
- Preserve custom pet freshness limits when reopening and saving Options without changing those fields.
- Offer optional direct Life360 account connection with password or access token. HomeCircle creates ordinary HA device trackers for discovered members; existing Life360 entities remain selectable without direct connection. People can also be selected from trackers without creating HA Person records.
- Route managed tracker connections through a provider registry so future built in sources can have separate credentials, setup steps, tracker ownership and lifecycle while sharing the existing HA entity and household model.
- Allow any registered tracker provider to complete account setup before its trackers appear, then choose members in Options after discovery.
- Route account repair to the provider that reported the authorization failure, so future connected tracker services can have separate reconnect forms.
- Keep the setup prompt visible until a tracker from the connected account is explicitly selected, even when other household members already exist.
- Prevent disconnecting a tracker account while a selected Home Assistant Person is configured to use, or currently reports from, one of its trackers.
- Report malformed Life360 location fields as an unexpected provider response while treating intentionally unshared locations as unavailable.
- Keep checking Life360 for newly added Circle members after initial discovery, track failures per member, and show tracker discovery status in HomeCircle Options.
- Classify provider failures with safe health codes, export sanitized Home Assistant diagnostics, and open a reauthentication repair flow when Life360 rejects a saved credential. Document the same issue workflow for future built in providers.
- Keep other Life360 members updating when one direct tracker is disabled or access to one Circle or member is denied. Stop retrying a rejected credential until it is repaired, cancel an active refresh on unload, and create TLS contexts off Home Assistant's event loop.
- Reject a tracker assigned to more than one household member.
- Recover saved direct trackers as unavailable during an offline restart, retry cleanly after a failed tracker-platform setup, and check account access when every member request is denied.
- Verify Life360 account continuity when replacing credentials or reconnecting; reject a different verified account while preserving selected trackers. For older development entries without a saved account identity, compare the old and new sign-ins when possible, or require explicit same-account confirmation when the old sign-in cannot be verified.

## 0.1.0-beta.10 — experimental prerelease

- Let a full-height HomeCircle card cover the viewport in kiosk mode, including HA's title bar and dashboard margins. Exit kiosk restores the ordinary view.
- Use a selected GPS tracker's valid `last_seen` location timestamp when no report-time sensor is configured. Keep the iPhone location report time unknown when that attribute is absent.
- Show battery level and charging state from the selected location tracker when no explicit supporting sensor is configured. Explicit sensor mappings retain priority.

## 0.1.0-beta.9 — release candidate

- Draw single and grouped member markers as pins whose tips identify the map location, leaving the avatars above the point.
- Fit the map with enough space for the taller pins and keep grouped avatars clear of zoom controls on narrow displays.

## 0.1.0-beta.8 — experimental prerelease

- Show HA person portraits or selected Life360 person and pet tracker portraits on member cards and map markers, with initials when an image is absent or fails to load. Limit external portrait requests to Life360 image hosts and omit the HA page referrer.

## 0.1.0-beta.7 — experimental prerelease

- Guide each member toward one linked tracker by showing current GPS/presence capability and the HA active source; leave equally suitable choices for the user. Existing saved selections remain intact during edits.
- Replace overlapping map counts with a compact member portrait cluster. Use HA-served pictures when available and initials otherwise; tapping the cluster still opens individual member choices.

## 0.1.0-beta.6 — experimental prerelease

- Make member setup easier to scan with household progress, readable Home Assistant entity names, clearer tracker and residence labels, and help beside each field. Show pet location timing on a separate pet-only step. Tracker suggestions and saved selections retain their existing behavior.
- Keep battery, charging, speed and driving sensors on a short status screen. Configure location report times on a separate screen for each source; guide older single-source timestamp mappings through that screen without discarding them.
- Show a readable draft summary before saving the household, including homes, trackers, optional sensors, source-specific report times and pet timing.
- When a location source has no genuine report-time sensor, show when Home Assistant last updated that source state while keeping the location report time explicitly unknown. HA observation time does not determine GPS freshness.
- Keep the owned dashboard card resource stable when saved HomeCircle settings trigger an automatic reload, while retaining cleanup on unload or failed setup.
- Keep the same owned dashboard resource when an unchanged Reconfigure save triggers a Home Assistant reload.
- Give member cards separate place, battery, and report-time labels; make stale reports easier to scan while keeping HA observation age distinct from an unknown location report time.
- On narrow card widths, place member status beneath the name, use two readable rows of category buttons, and shorten the map so the member list starts sooner.
- Keep keyboard focus on the selected member card after choosing a map marker or a member from an overlapping-marker group; keyboard activation scrolls the card into view without making touch activation jump the page.
- Preserve keyboard focus on clustered markers and expanded member choices when the map redraws, and expose whether a cluster is expanded.
- Offer an opt-in full-height wall-display layout so the map uses space below the card without hiding category controls or member cards.
- Offer a reversible kiosk control on full-height cards, with an optional URL setting that opens the page with Home Assistant navigation hidden in that browser.

## 0.1.0-beta.5

- Limit failed household snapshot retries to the regular refresh timer; reconnecting still refreshes immediately.
- Clean up an owned dashboard resource when a HomeCircle entry is removed while not loaded, using its persisted ownership ID. Removal remains safe for unrelated and manually registered resources.
- Add focused regressions for failed-request retries, scheduled refresh, reconnects and unloaded-entry cleanup. These changes are not in the published beta 4 ZIP.

## 0.1.0-beta.4

- Per-source location report timestamp mappings, preserving legacy single-source settings.

## 0.1.0-beta.3

- Show report ages in minutes, hours and days with visible stale indicators.
- Add explicit Person/Pet settings and separate pet Home/Away freshness thresholds.
- Preserve supporting sensor mappings when editing member settings.

## 0.1.0-beta.2

- Responsive member layout and larger map zoom touch targets.
- Preserve tile-failure notice during member/category selection and clear it after a successful tile-loading cycle.
- Initial real-source acceptance with iPhone, Life360 and existing separate Pet GPS integration.

## 0.1.0-beta.1 — development prerelease

First experimental packaged prerelease for disposable HACS acceptance. Includes the integration, bundled card, visual editor and original brand icon. Official HA and HACS repository validation passed before packaging. Real-provider acceptance and production rollout remained pending at that checkpoint.

## Development history before beta 1


### Added
- HomeCircle project scaffold and provider-independent product definition.
- ADR-001: standard Home Assistant entities are the location-provider boundary.
- Frozen local reference snapshot with source hashes; public generic reference specification.
- V0.1 feature scope, acceptance criteria, privacy checks, and main/feature-branch workflow.

- Milestone 1 config/options/reconfigure flows with HA entity selectors, explicit tracker confirmation, primary Home, ordinary places and per-member additional residences.
- Atomic selection persistence, duplicate-entry prevention, validation of removed/disabled selections, state subscriptions, automatic options reload and cleanup on unload.
- Missing-source repair notice and recovery; renamed sources require explicit reselection.
- Local development manifest and English translations; maintainer and repository fields completed during release preparation.
- Pinned HA 2026.9.4 test environment, focused HA flow tests and separate-process restart validation with synthetic sources.

- Milestone 2 normalized member records, Home/Away/Driving/Unavailable counts and separate primary-house/all-residence/overview focus sets.
- Source and timestamp provenance, coordinate validation/conflict handling, optional explicit battery/charging/speed/driving/report-sensor mappings, and automatic aging without provider polling.
- Synthetic regression coverage for residence counts, locationless presence, stale driving, source switching, unknown timestamps, overlapping zones and optional values.
- Reproducible disposable browser launcher; frontend missing-dependency and custom-component import-root issues resolved.

### Status at that checkpoint
The card and authenticated frontend access were implemented. Packaged Core lifecycle validation passed; actual HACS acceptance and public release were still pending.

### Milestone 3 development — 0.0.3-dev1

- Add permission-checked normalized websocket snapshots and owned Lovelace resource registration.
- Bundle Leaflet with its license; ship the initial dark responsive card and visual editor.
- Add category/member/overview focus, overlapping-marker selection, per-card visibility, and optional disclosed OSM tiles.
- Verify UI-only card installation, recovery, portrait layout and independent card instances with synthetic data.

### Release preparation

- Set jmhjr maintainer/repository metadata and configure ZIP-based HACS distribution.
- Add deterministic package builder, archive inventory and isolated package lifecycle validation.
- Record user-confirmed physical DAKboard touch, unavailable-state and recovery checks.
- Support explicit private LAN binding for disposable physical-display QA, keeping loopback as the default.

### Official HA validation

- Pass unmodified Core 2026.9.4 hassfest with no invalid integrations or warnings.
- Declare HTTP dependency, UI-only config schema and required manifest ordering.

### Public development review

- Label the repository experimental and publish it for development review.
- Pass all nine official HACS remote validation checks after privacy review.
- Use the maintainer GitHub no-reply address in published branch history.

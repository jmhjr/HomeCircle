# Acceptance plan

Flow/lifecycle, normalization, authorization, provider, and dashboard tests run against HA Core 2026.9.4. See the [stable scope audit](../docs/STABLE-SCOPE-AUDIT.md), [beta 16 validation](../docs/BETA16-VALIDATION.md), and [test commands](../docs/DEVELOPMENT.md). Automated tests do not imply real provider or physical-display acceptance; those checks have separate records.

| Area | Required cases |
|---|---|
| Configuration | Discover people; active vs associated trackers; explicit fallback; cancel; duplicate entry; edit; removed entity; reload |
| Provider independence | Entity-only setup works with no Life360 account; two independent tracking sources; optional clients start only after explicit connection; two managed providers keep separate accounts, setup steps and tracker ownership |
| Presence | Home, Away, evidenced Driving, Unknown/Unavailable; driving precedence; locationless Home |
| Residences | Member at primary house and at assigned dorm both count Home; house-only Home focus excludes dorm; ordinary places remain Away |
| Location | Null, zero, range limits, missing accuracy, invalid values, source conflicts; unavailable points cannot focus |
| Freshness | Report time separate from HA observation time; unknown timestamps; stale driving visibly qualified |
| Optional fields | Battery/charging absent; battery zero; explicitly mapped sensors; unknown speed unit hidden |
| Card | Member focus; group expand/collapse; category focus; empty categories; overview reset; two independent card instances |
| UI setup | Fresh HA/HACS install through card display without editing YAML; options survive restart |
| Packaging | Bundle registration once; upgrade/unload/removal; no damage to unrelated resources |
| Direct Life360 recovery | Partial Circle/member denial, whole-account rejection, failed platform setup and reload, same-account reconnect, offline restart with saved trackers |
| Privacy | No raw states in logs/diagnostics; no personal artifacts in source/release; optional network providers disclosed |
| Display | Portrait overflow, keyboard/touch focus, missing-data labels; physical DAKboard/TouchHub separately from automated tests |

The generic fixture in `fixtures/household.example.json` matches the milestone 1 selection snapshot. Synthetic numeric coordinates used by tests are explicitly zero via HA attribute constants; they are fictional test data, never a household location. No privacy checker exception is needed.

Run `scripts/validate_life360_offline_restart.py` with the pinned test Python to check a saved direct tracker across two disposable Core processes. Its provider replies and credential are fictional, and its storage is removed afterward.

Beta 18 adds source-ranking regressions (all-stale fallback, per-source reports, near ties, HA accuracy/passive zones), native upload/reference persistence, crop/Back races, coarse battery categories, saved-place selection/Skip/partial retry/concurrent changes, and Photon authorization boundary, transport fragmentation, bounded cache/budgets, failure, unload/remove and pending-write checks. Synthetic requests and images contain no private data. See [beta 18 validation](../docs/BETA18-VALIDATION.md).

# Linux and HAOS candidate validation

October 19–20, 2026. **ARM64 QA checks passed on both Core targets; actual
HAOS-managed Core 2026.10.2 loading/restart and native checks passed on ARM64 and
emulated AMD64. All three recorded Linux backend targets passed the final suite.**
The October 19 emulated AMD64 upgrade/rollback and recovery attempts **failed
their bounded checks**. The separate [October 20 native AMD64 container run](#october-20-native-amd64-container-upgrade-and-recovery)
**passed both exact-baseline upgrade/rollback sequences and full synthetic recovery**.
This continues the [platform, upgrade and recovery validation](PLATFORM-UPGRADE-RECOVERY-VALIDATION.md)
for the same unreleased 112-file candidate, manifest `0.1.0-beta.19`:

`f0477a91e78181fe1f8d80ada176a1739e10a7502abe7ee6ee2240571280d1f5`

The earlier Linux evidence covered official-wheel resolution and ELF inspection.
The October 19 phase used new disposable HAOS virtual machines to obtain actual
Linux process evidence. October 20 adds an authorized public validation branch
and a disposable native Linux CI runner. Production Home Assistant, owner
accounts and the published release package remain unchanged. No additional Mac
Python is part of either Linux phase.

## Runner and acceptance scope

The fresh runner is official Home Assistant OS **18.3 Generic aarch64**, with
managed Home Assistant Core **2026.10.2** running. Its Core environment is
**Python 3.14.6**, **Alpine 3.24.1**, **musl**, **ARM64/aarch64**. The separate
disposable QA container uses the same official qemuarm64 image, recorded SHA-256:

`5958cd8bcf451966db72682c2d715db1e5a10d66f0e2c3d580dccffd86124e23`

A parallel official ARM64 Core **2026.9.4** container uses Python **3.14.6**,
Alpine **3.24.1** and musl, recorded image digest:

`dd1ad589936601cacb1b4797d17e27ce762b5147fb46b0e8e3d5486ab95e56c3`

The second fresh HAOS 18.3 guest runs actual x86_64 Linux under QEMU/TCG on the
Mac ARM host. Its official qemux86-64 Core **2026.10.2** image is recorded as:

`45f009d6ff1061971102e81f0802cf2762bdd5c5007231c938bd36030cbd0a12`

| Scope | Current evidence | Candidate acceptance |
| --- | --- | --- |
| Fresh HAOS 18.3 ARM64 runner | Managed Core 2026.10.2 is running; target environment identified | Environment preparation only |
| Separate ARM64 Core 2026.10.2 QA container | Exact candidate verified; active dependency closure, native runtime, regression suites, upgrade and recovery checks passed | Qualified QA-container scope below |
| Parallel ARM64 Core 2026.9.4 container | Same exact candidate passed native/lifecycle, 1,443 backend tests and both upgrade/recovery sequences | Container scope; no managed Core 2026.9.4 service claim |
| HAOS-managed Core 2026.10.2 process | Core installed manifest dependencies, loaded the exact candidate through its real flow, then restarted with the saved configuration intact | Passed for the explicit synthetic Person/tracker setup below |
| Fresh HAOS 18.3 x86_64 guest under QEMU/TCG, Core 2026.10.2 | Actual Linux native/lifecycle, 1,443 backend tests and managed Core installation/flow/restart/native checks passed | Emulated CPU scope; separate full AMD64 upgrade/recovery follow-up failed its bounds and remains unqualified below |
| Native x86_64 Ubuntu 24.04 CI host, pinned Alpine/musl Core 2026.10.2 Docker container | Both ten-phase exact-baseline upgrade/rollback sequences and twenty-process full synthetic recovery passed | Native AMD64 container scope; no native HAOS-managed service, glibc Core, backend-suite or separate worker/lifecycle rerun claim |
| Linux glibc, AMD64 Core 2026.9.4 and additional targets | Earlier official-wheel and ELF checks retain their dated scope | Actual runtime acceptance pending |

A QA-container result establishes behavior in the recorded image and architecture.
Actual loading by the separate HAOS-managed Core process is a further check of
manifest dependency installation and integration startup. Neither result alone
establishes a different recorded target, libc, Core version, live Apple recovery,
production upgrade or physical-display acceptance.

## Offline native and worker checks

The existing [platform validator](../scripts/platform_validate_candidate.py)
binds its receipt to the exact candidate archive, checks the active installed
dependency closure against Core constraints, and runs the packaged worker with
a generated Mach-O dispatcher. It separately requires the unchanged production
library verifier to refuse that synthetic image. It uses no Apple binary,
account, owner configuration or external request.

The new Linux-only [worker lifecycle validator](../scripts/platform_validate_linux_lifecycle.py)
additionally imports the actual `provider.Worker` from the extracted candidate
and exercises its real asyncio pipe and process-ownership paths. It requires:

- Successful open/check/close, repeated close, cleared process handles and absence
  of each reaped PID from `/proc`.
- The actual Unicorn 2.1.4 package copied into a disposable dependency directory
  visible only to the parent; the child must use the worker's explicit package
  loader to load that copy.
- Observed live child limits of 90 CPU seconds, zero core-dump bytes and 3 GiB
  address space.
- Cancellation after CPU progress proves an active synthetic native call, followed
  by the real provider's kill/wait cleanup and PID disappearance.
- Unchanged extracted candidate files, denied external networking and complete
  disposable-storage cleanup.

The validator refuses non-Linux execution before inspecting an archive or
launching a child. Only its in-memory synthetic library digest/length and loader
observation are substituted; candidate source and package bytes remain unchanged.
The outer probe owns a new process group and tears it down on unsuccessful
outcomes, including interruption or an exited probe with surviving workers.

Source review found and corrected two cleanup defects in this new validator
before execution: suppressed close errors and incomplete process-group cleanup
after probe failure/interruption. Six focused guard/parser/fixture/cleanup test
cases cover these checks. These are harness changes, not confirmed candidate defects.
All six cases passed in the completed Linux backend suite.

The exact-archive native check passed with **24 installed dependencies** in its
active closure and **no Core constraint mismatch**. Mandatory imports, synthetic
native dispatch and production-hash refusal passed. The lifecycle check passed
with the parent-only Unicorn copy, verified live limits and active native
cancellation. Both owned workers were killed by the provider's normal close
path, reaped and absent from `/proc`; temporary storage was removed. These are
synthetic guest instructions, not an Apple binary or provisioning acceptance.

## Public anonymous Apple runtime

A separate exact-candidate runtime check completed with outcome **ready** on
ARM64 Core **2026.10.2**. It verified the pinned public installer/library, made one public
download and three anonymous provisioning requests, generated OTP headers,
round-tripped the encrypted vault and restored the same identity with a stable
machine ID in a cold worker. All four workers were reaped and disposable storage
was removed. It made **zero Apple-account requests**, read no owner data and
accessed no locations. This check does not sign into an owner account or perform
Keychain recovery.

## Regression, upgrade and recovery results

The final ARM64 Core **2026.10.2** backend run passed **1,443 tests**, with **one optional public
installer fixture skipped**, in **41.76 seconds**. This is the expanded Linux suite;
the earlier 1,430-test Mac checkpoints retain their own dated scope. Ruff passed,
and the public-file guard checked **326 files** without flagged patterns. The
automated privacy scan does not replace manual review.

Both exact upgrade baselines passed ten phases each: the immutable published
beta 19 archive and the reconstructed recorded-patch archive, for **20 separate
Linux Core processes**. These cover upgrade, restart, identity-ledger persistence,
package-only rollback, re-upgrade and matching complete-backup restoration. Saved
people/items, options, places, entity IDs, encrypted account material, HomeCircle
activity, request reservations, portrait bytes and HTTP delivery, dashboard,
resource identity and served card bytes were preserved within the documented
scope. Only the final report transport was replaced with an empty response;
external connections were denied. The existing package-only rollback limitation
remains: published beta 19 polling drops the newer identity ledger, while the
matching stopped package and complete storage backup restore its recorded state.

The full synthetic recovery/repair sequence also passed in **20 distinct Linux
processes**. All **40 network-denial probes** were blocked, with **zero unexpected
network attempts and zero Apple requests**. It covered interrupted migration,
guard locks/acknowledgment/corruption, encrypted-vault corruption/wrong-key/foreign
account refusal, matching backup restoration and retained newer guard state.
All ordinary children exited zero; explicitly expected fault exits remained
separate. This exercises the Core storage lifecycle and recovery functions,
not a live owner recovery or a full integration lifecycle in each recovery child.
Synthetic recovery storage was removed.

Two confirmed QA setup defects were fixed before these final runs. The official
image's distribution metadata did not identify the imported Core source tree, so
the platform validator now reads constraints beside the active imported Core and
has origin-selection regressions. The installed `tests` package also collided
with the checkout's namespace; a local `tests/__init__.py` and consistent helper
imports make collection explicit. These were validation-environment defects;
the exact candidate archive and runtime source remain unchanged.

### First AMD64 full-suite invocation and recovery-test deadline

The first full AMD64 run returned **one failed, 1,439 passed and one skipped** in
**528.05 seconds**. That is a failed invocation. Its sole failure was the
recovery test wrapper's 90-second aggregate subprocess deadline. The retained
receipt contains 12 completed guard phases with their expected exits/statuses;
the thirteenth started about 83 seconds after the first and had no completed
receipt when the parent deadline expired. No guard assertion failure appears in
those partial records, and the incomplete phase is not a passing result.

The reviewed QA-only correction derives a **790-second aggregate allowance**
from the 13-process plan: `12 * (45 + 10) + 60 + 10 + 60`. Individual child limits remain **45 seconds**, bounded
reaping remains **10 seconds**, and the held child's watchdog remains **60
seconds**. The test wrapper also owns a fresh process group and kills/drains it
on failed exit, timeout, interruption or receipt-validation failure, including
descendants whose leader already exited. Three fake-process regressions cover
timeout, an exited probe and invalid receipt cleanup. The complete ARM64 suites
were rerun after these validation changes; their final counts above and below
include the three new cases. No candidate runtime limit or source changed. The
focused AMD64 rerun passed the actual 13-phase guard plus the three cleanup
regressions: **four tests passed in 94.44 seconds**. The corrected full AMD64 run
then passed **1,443 tests**, with **one optional public installer fixture
skipped**, in **473.70 seconds**. Its job exited zero. The first failed invocation
remains retained as failed evidence.

## ARM64 Core 2026.9.4 container

The parallel official Core 2026.9.4 container completed the same exact-candidate
native and lifecycle checks with **24 installed dependencies** and **no Core
constraint mismatch**, including setuptools **81.0.0** and protobuf **6.32.0**.
The native worker executed, the production verifier refused the synthetic image,
and the real provider's dependency-path, live-limit, cancellation and reaping
checks all passed.

Its final full backend run passed **1,443 tests**, with **one optional public installer
fixture skipped**, in **41.31 seconds**. Both exact upgrade baselines completed
ten phases each, for **20 additional Core processes**. The full recovery/repair
sequence passed in **20 distinct processes**, with **40 blocked network probes**,
zero unexpected network attempts and zero Apple requests. The same rollback and
synthetic-storage scope limits apply. The bounded QA container's main job exited
zero when complete.

Each result runs the same expanded test suite on a separate target.
This qualifies the recorded Linux ARM64 Core 2026.9.4 **container** environment;
the HAOS-managed Core service remained 2026.10.2. No managed 2026.9.4 setup or
owner-account acceptance is claimed.

## Actual HAOS-managed Core loading and restart

The exact candidate was also installed into the fresh HAOS-managed Core
**2026.10.2** instances on **ARM64 and x86_64**, separately from their QA
containers. The latter is the emulated QEMU/TCG guest. Core installed mandatory
manifest dependencies through the normal integration-loading path; the managed
instances did not receive the QA containers' test SDKs or pytest extras.

The exact-ZIP native validator then also passed inside both managed Core
containers: all mandatory imports, each 24-dependency active closure, imported-Core
constraints, synthetic native dispatch, production-hash refusal and process
reaping. The ARM64 managed closure differs from its QA container for unpinned
transitive dependencies: managed Core resolved certifi 2026.10.18 and multidict
7.1.0, while QA retained certifi 2026.7.22 and multidict 6.9.1. Both complete
inventories are retained and both satisfy the active Core constraints. The
x86_64 managed closure also passed with certifi 2026.10.18 and multidict 7.1.0.

A temporary helper integration outside the candidate used Home Assistant's
supported persistent-Person creation API and the actual HomeCircle configuration
flow. It explicitly selected that synthetic Person and a synthetic tracker at
0,0, assigned the tracker, confirmed the member settings and saved. The candidate
loaded with its real frontend resource and automatically created dashboard.
No owner user, API credential, Apple account or direct provider was used, and no
HomeCircle code or service was patched.

The helper recorded all **112 installed file hashes** against the exact candidate
inventory before and after a normal managed-Core restart on **each architecture**.
Each fresh process had a different Linux start token. Within each instance, the
stored entry ID, selected Person/tracker and
their registry IDs, entry data, empty options, runtime-configuration digest,
owned frontend resource ID/URL and dashboard ID/configuration digest were
identical. The helper found and verified the saved entry and Person after
restart; it did not recreate them or repeat the configuration flow. All four before/after receipts
passed. These are independent synthetic instances, not shared registry IDs
between architectures.

This proves fresh managed installation, explicit provider-independent selection
and restart retention for that synthetic setup. It is separate from the fuller
QA upgrade/recovery scenarios and does not claim a current production/HACS
upgrade, nonempty options coverage in this managed check, owner-account access,
live location reports or physical-display acceptance.

## Results and remaining work

| Check | Status |
| --- | --- |
| Exact candidate archive/inventory in Linux | Passed; same 112-file SHA-256 |
| Manifest dependency installation and Core constraint agreement | Passed in QA container; 24 installed dependencies, no mismatch |
| Packaged native dispatcher and production-hash refusal | Passed |
| Real provider worker limits, dependency path, cancellation and reaping | Passed |
| Public anonymous Apple runtime | Ready; four workers reaped, no owner/account/location access |
| ARM64 backend regression suites | 1,443 passed and one optional fixture skipped on each of Core 2026.9.4 and 2026.10.2; 41.31/41.76 seconds respectively |
| Emulated AMD64 Core 2026.10.2 backend suite | 1,443 passed and one optional fixture skipped; 473.70 seconds |
| Exact candidate loaded by HAOS-managed Core after restart | Passed on ARM64 and emulated x86_64; all 112 hashes and each instance's saved identity/configuration/resource/dashboard snapshot retained |
| Native execution and installed closure inside managed Core containers | Passed on ARM64 and emulated x86_64; 24 dependencies each, no active Core constraint mismatch |
| ARM64 exact-baseline upgrade/rollback and recovery restart sequences | Passed on each Core target within the synthetic scope above |
| Linux amd64 execution | Native/lifecycle, full backend suite and managed setup/restart/native checks passed under QEMU/TCG |
| Native AMD64 Core 2026.10.2 container upgrade/rollback and full recovery | Passed October 20: 20 upgrade phases across both exact baselines, 20 recovery processes and 40 blocked probes; unchanged frozen candidate and CLI limits |

Each backend result runs the same expanded suite on a separate target. The full
emulated AMD64 upgrade/recovery follow-up below failed its bounded checks. The
later native AMD64 container run passed those synthetic scenarios separately.
Glibc, AMD64 Core 2026.9.4, native AMD64 HAOS-managed service acceptance and additional runtime scopes remain
unqualified. The previous Mac
finalization crashes remain unattributed; this phase does not claim to repair
their cause. Live recovery, long-term report behavior, current production installed-state
and HACS upgrade, Recorder continuity, physical DAKboard acceptance and the
remaining license/service-use gates remain separate.

Ignored runner records, exact-input receipts and Linux outputs are retained
under `work/linux-haos-validation/`. Public reports contain no owner records,
credentials, private identifiers or locations.

## October 19 follow-up: AMD64 upgrade, rollback and full recovery

**These emulated attempts failed; no passing upgrade/rollback or recovery result
from this follow-up.** The [later native container run](#october-20-native-amd64-container-upgrade-and-recovery)
provides separate passing evidence. This
milestone reused the disposable HAOS 18.3 x86_64 guest and its official Core 2026.10.2
image under QEMU/TCG. It keeps the same frozen 112-file candidate digest above.
The earlier completed checks and first failed AMD64 backend invocation retain
their recorded results and limits.

The upgrade/rollback inputs were the same two exact 109-file baselines:

- Published beta 19: `5f20d536e1b5378bef7f0b972bbfbc7ced911063aea16a0a8f56d2ffa1210cd2`.
- Reconstructed recorded patch: `0362a71b0d12e12bbe38c20192f130f505011500e9a1d31a3531547c5055d80a`.
  This remains a reconstruction from retained hashes, not a fresh production
  installed-state snapshot.

| Follow-up check | Requested scope | Observed result |
| --- | --- | --- |
| Published-baseline upgrade/restart/rollback | Ten phases with exact package, loaded-version and saved-state checks | Two affected-clock attempts and the corrected-clock attempt failed at the first child deadline; zero completed phases |
| Reconstructed-baseline upgrade/restart/rollback | Ten phases with the same checks; 20 Core processes requested across both baselines | Not reached; unqualified |
| Full synthetic recovery/repair | Twenty distinct processes; guard, interrupted migration, vault refusal and matching backup restore checks | The affected-clock and corrected-clock attempts failed at the first child deadline; zero completed phases |
| Recovery isolation and cleanup | Complete probe accounting, retained-guard and temporary-storage acceptance | Unqualified; no complete 20-process/40-blocked-probe result |

### Failed follow-up invocation audits

The initial driver invocation and its quiet retry both **failed** in the older
published baseline's first `published_install` child at the unchanged
**180-second** deadline. Neither produced a completed phase receipt or assertion
result. Both drivers recorded `completed: false`, `outcome: failed` and no
completed jobs. Neither invocation counts as a passing upgrade, rollback or
recovery scenario; both input receipts still matched the frozen candidate and
both exact baselines.

Managed Core and Matter startup were observed concurrently under QEMU/TCG during
the first attempt. Both services were stopped before the quiet retry, and the QA
process list contained only its sleep process with no Python child. The second
attempt used a fresh result directory, the same pinned scripts and unchanged
**180-second child / 2,100-second complete-upgrade** limits. The timeout cause
remains unconfirmed. Both driver receipts and published-stage logs are retained
under `work/linux-haos-validation/amd64-upgrade-recovery/`.

The independent full recovery/repair attempt also **failed**. Its first
`guard_verified` child exceeded the unchanged **45-second** bound and was killed
with exit **-9**. The receipt marks `timed_out: true`, `completed: false`,
`failed: true` and `expected_fault_exit: false`; this was not one of the deliberate
fault phases. **Zero recovery phases completed.** The attempt does not establish
the requested 20-process sequence, 40 blocked probes or final recovery/cleanup
acceptance. It used the unchanged frozen CLI and reviewed owned-session runner
with a **1,200-second** outer bound; the existing **10-second reap** and
**60-second held-process watchdog** bounds were unchanged. Its driver, partial
receipt and inner log are retained alongside the two failed upgrade attempts.

### Bounded diagnostic and disposition

A separate diagnostic stopped after **203.737 seconds**, retaining the
**180-second phase** deadline and a **240-second total** bound. It recorded
`diagnostic_only: true`, `acceptance_pass: false` and `TimeoutExpired` for the
older published baseline's `published_install` phase. The candidate upgrade
phase was not reached. Repeated 30-second stack captures sampled Core and
SQLAlchemy imports at 30/60 seconds, startup translation/dependency-metadata and
mashumaro work at 90/120 seconds, and the published baseline's `indexed_keys`
elliptic-curve work at 150 seconds. These samples identify observed execution
paths; they do not establish the timeout cause or a candidate runtime defect.

The diagnostic verified all three archive digests, validation-script pins and
the exact 112-file candidate source inventory **before and after**. The
candidate, both baselines and public validation scripts remain unchanged.
Diagnostic outputs are retained under
`work/linux-haos-validation/amd64-upgrade-diagnostic/`. Seven synthetic driver
regression cases passed in Linux in **5.34 seconds**; these qualify the ignored
orchestrator's guards and cleanup, not either failed acceptance scenario. That
new helper's corrections bound the recovery source to the frozen candidate and
route SIGTERM/SIGHUP through owned-process cleanup; they do not change runtime
code.

No additional blind reruns or relaxed limits were part of this follow-up. Its
disposition required a faster/native AMD64 runner or a confirmed runner issue
and fix before another acceptance attempt. The native runner result below is
recorded separately.
The existing package-only rollback identity-ledger limitation and requirement to
retain the newest recovery guard still apply. These are synthetic QA-container
scenarios, separate from the already verified managed-Core setup/restart checks.
They do not add owner sign-in, live Apple recovery, current production/HACS,
Recorder or physical-display acceptance. Glibc, AMD64 Core 2026.9.4 and other
runtime targets remain unqualified. No Mac Python or production/owner data is
part of this follow-up.

### Runner clock incident and gated retry

Cleanup exposed a confirmed clock-integrity problem in that emulated guest
boot: guest wall time froze while host time advanced, and guest uptime nearly
stalled and then moved backward. The kernel had marked TSC unstable and fallen
back to the 24-bit `acpi_pm` clock, with a reported maximum idle interval of about
2.085 seconds; the VM had HPET disabled. The failed attempts above remain failed
and incomplete. Their configured deadlines and guest-reported elapsed times,
including the diagnostic's 203.737 seconds, are retained audit values, not
independently validated host durations. This runner issue does not establish the
sole cause of any earlier timeout or a candidate defect.

Only the stopped disposable AMD64 VM's supported UTM setting
`QEMU.MachinePropertyOverride = hpet=on` was changed. The before/after
configuration comparison found no other semantic change; the generated machine
arguments include `q35,hpet=on,vmport=off`. The next boot selected `tsc`, with
`tsc hpet acpi_pm` available. Candidate code, the three frozen archives and the
pinned validation scripts were not changed.

The first host-clock gate **failed overall** because its QA criterion rejected
a guest sleep of 5.81 seconds above a fixed 5.5-second ceiling, although it
completed within a 6.463-second host observation envelope and both clock-rate
interval checks passed. That receipt is retained. The reviewed second criterion
separates clock rate/drift from timer liveness: two 30-second host/guest timestamp
intervals check clock rate, and three minimum-wait probes must complete within
independent 15-second host bounds. It does not require exact five-second
scheduler performance. Seven host Ruby regression cases cover the corrected
gate criteria separately from the seven Linux orchestrator cases above.

The second gate **passed for runner clock behavior only**, in about **78.83 host
seconds**. TSC stayed selected, both interval comparisons passed and all three
timer-liveness probes completed within their host bounds. Its receipt explicitly
records `outcome: passed_clock_gate_only`; it does not record candidate acceptance.
Both gate receipts, raw host/guest brackets and helper hashes are retained under
`work/linux-haos-validation/amd64-clock-fix/`.

The confirmed runner change and this bounded gate supported a new acceptance
attempt with the unchanged exact-input driver, independent host watchdog and
30-second host/guest clock monitoring. The gate adds no candidate acceptance
pass. Earlier failed attempts and all owner, production, rollback and other
platform limits remain in force.

### Corrected-clock upgrade and recovery outcomes

The corrected-clock full upgrade attempt **failed** after **260.377106 host
seconds**, measured by the independent host monitor. All **eight workload clock
checks passed**, with TSC selected throughout. Nevertheless, the older published
baseline's first `published_install` child still exceeded its unchanged
**180-second** deadline. The driver recorded `completed: false`, `outcome: failed`
and no completed jobs. There was no valid phase JSON or candidate phase result;
the reconstructed baseline was not reached. Both baselines' full upgrade/rollback
acceptance in this emulated attempt therefore remains **unqualified**, and no candidate
runtime defect or sole timeout cause is established.

The same official QA image, exact-input driver and frozen candidate/baseline
inputs were retained. The host monitor confirmed the exact QA container stopped
after the failure, with no host cleanup failures. The host receipt, guest driver
and published-stage log are retained under
`work/linux-haos-validation/amd64-clock-fix/`, including
`host-monitor-20261020T043333Z-fd9f36390ff4664917556f90/host-monitor.json`.

The one separate corrected-clock full recovery attempt also **failed**, after
**110.627503 host seconds**. All **three workload clock checks passed**, with
TSC selected. Its first `guard_verified` child exceeded the unchanged
**45-second** deadline and was killed with exit **-9**. The single partial
receipt records `timed_out: true`, `completed: false`, `failed: true` and
`expected_fault_exit: false`. **Zero recovery phases completed**, and the driver
recorded no completed jobs. This is no full recovery, 20-process or
40-blocked-probe acceptance result.

The recovery driver's archive/script pins and exact 112-file source inventory
matched before and after execution, with `candidate_changed: false`. Its exact
QA container was confirmed stopped, with no unresolved container cleanup or
host cleanup failures. The host receipt is retained under
`host-monitor-20261020T044327Z-4a96a26653de349c07532360/host-monitor.json`, alongside
`hpet-recovery-driver.json`, `hpet-recovery.json` and `hpet-recovery.log` in the
same ignored clock-fix evidence directory.

Both full upgrade/rollback and full recovery in these emulated attempts remain **unqualified**. The
corrected-clock failures do not establish a candidate bug or a sole timeout
cause. **No further emulated retries were part of this milestone.** Earlier failed
attempts, the clock incident and gate failure, and all prior passing scopes and
remaining release limits are preserved.

## October 20 native AMD64 container upgrade and recovery

The authorized [GitHub Actions run 39426549335](https://github.com/jmhjr/HomeCircle/actions/runs/39426549335)
**passed** on a native x86_64 Ubuntu 24.04 host, kernel
`6.17.0-1022-azure`, at validation revision
`50f9fa38ca3f88e68a9734637ec1ec84203ce8dc`. The host wrapper measured
**223.990 seconds**, including preparation, acceptance and owned-container
cleanup. This is a new native runner result; it does not convert the earlier
QEMU/TCG attempts into passes or identify their sole timeout cause.

Acceptance ran inside the same pinned official **Core 2026.10.2** image,
**Python 3.14.6**, **Alpine 3.24.1/musl**, with actual container architecture
`x86_64`. The registry reference was
`ghcr.io/home-assistant/qemux86-64-homeassistant@sha256:45f009d6ff1061971102e81f0802cf2762bdd5c5007231c938bd36030cbd0a12`.
Docker separately recorded local image ID
`sha256:e1acee126eee45b3007494ad7f806d12535dc7d733624b681ed29a505f8c2b98`;
the registry digest and local image ID are different identifiers. All **24
manifest dependency-closure packages** satisfied the active Core constraints,
whose SHA-256 remained
`7baa9a8f39ddeb9c5bb60a1036f6d5e33f4b84267f151f53cc2b95ef031a21b5`.
Only the six manifest requirements were requested; their 24-package closure was
verified. The test plugin and reference SDK were unnecessary for these standalone CLIs.

The frozen exact-input driver retained SHA-256
`c910ef815d34eb4379bf3f0e1fd6dad31d95986a287b9e32263f9b87b60de373`.
The candidate digest, all **112 files**, both exact **109-file baselines**,
inventory and validation-script pins matched. Setup verified fixed hashes before
extracting or importing candidate code. Dependency downloads were confined to
setup; the container had **no connected Docker network** during acceptance and
no host bind mounts or Docker socket. The existing **180-second upgrade child**,
**45-second recovery child**, **10-second reap** and **60-second held-process
watchdog** limits were unchanged; the native outer acceptance bound was
**5,520 seconds**.

| Native container check | Result |
| --- | --- |
| Canonical published beta 19 → candidate, restart, rollback and coherent backup restoration | Ten phases passed |
| Reconstructed recorded patch → candidate and the same rollback/restoration checks | Ten phases passed; this code reconstruction remains separate from current production installed state |
| Full synthetic recovery and repair | Twenty distinct processes passed, including the expected deliberate fault exits and held-lock kill |
| Recovery network accounting | All 40 probes blocked; zero unexpected network attempts or Apple requests |
| Exact source, package and persistence assertions | Passed through the frozen driver, with final input/source matching |
| Host outcome and ownership cleanup | Acceptance and runner exited zero; exact owned container stopped and removed; `cleanup_failed: false` |

The package-only rollback identity-ledger limitation remains: published beta 19
can drop the newer ledger. Coherent matching backup restoration and retention of
the newest independent recovery guard are still required. No candidate runtime
fix, package rebuild, version change or production deployment was needed.

With explicit authorization, only the isolated public branch
`codex/native-amd64-validation` received the payload and workflow commits
(`2623de5` and `50f9fa3`). The main branch and the local working checkout/HEAD
were unchanged by that publication; no release or tag was created. The Actions
job completed successfully. Its upload action produced a nonblocking Node 20
deprecation/forced-Node-24 annotation; the artifact upload still succeeded.

Only **three sanitized JSON summaries** were uploaded and downloaded:
`host.json`, `setup-summary.json` and `candidate-summary.json`. The artifact is
**2,026 bytes**, retained by GitHub for **seven days**, with archive digest
`sha256:de782349ac77e0f9bcc08fc08961a395bf35cb67d580ab73972ddd4e466abc6a`.
Downloaded summaries and run/artifact metadata are retained under
`work/linux-haos-validation/native-amd64/`. Raw synthetic configurations,
per-phase receipts and logs were collected locally inside the ephemeral runner
for the bounded run, then were **not persisted in the uploaded artifact**. The
public summaries report the frozen driver's validated outcome; they are not a
retained raw per-phase archive. An independent read-only cross-check found the
three downloaded summaries, successful CI status and artifact archive digest
consistent with one another.

This closes the two-baseline upgrade/rollback and full synthetic recovery scope
for this native AMD64 **Core 2026.10.2 musl container**. The 1,443-test backend
suite, separate packaged-worker/native lifecycle validators and anonymous Apple
runtime were **not rerun** on this CI host. Native AMD64 HAOS-managed Core,
Supervisor/HACS behavior, Core 2026.9.4 on AMD64, glibc Core runtime and additional
targets remain unqualified. Ubuntu's host libc does not establish glibc
acceptance for Python running inside the musl container. Owner sign-in/live
Apple recovery, current production installed-state/HACS upgrade, Recorder
continuity, long-term field behavior, physical DAKboard acceptance, external
assurance and remaining licensing/service-use gates remain open. No Mac Python
or owner/production configuration was used.
